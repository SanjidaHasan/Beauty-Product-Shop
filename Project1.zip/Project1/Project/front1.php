<?php

@include 'config.php';





?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>home</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom admin css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>

<header class="header" style="background-color:black; ">

    <div class="flex">

        <nav class="navbar"style="background-color: black;">
            <ul >
            <li><a style="color:black;"> </a>
</li>
                <li><a  style="color:white;text-decoration:none" href="front.php">home</a></li>
                <li >

                                  <a style="color:white;text-decoration:none"  href="welcome.php" > My Profile</a>
                              </li>
                    
                </li>
              
                <li><a  style="color:white;text-decoration:none"  href="orders.php">orders</a></li>
                <li >
                     <a style="color:white;text-decoration:none" href="book_beauty_service.php" >Book Beauty Services</a>
                   </li>
                   <li><a  style="color:white;text-decoration:none"  href="register.php">Register</a></li>
                   <li><a  style="color:white;text-decoration:none"  href="Login.php">Login</a></li>
            </ul>
        </nav>

        <div class="icons" >
            <div  id="menu-btn"style="" class="fas fa-bars"></div>
            
            
           
        </div>

        

    </div>

</header>
<section class="home">

   <div class="content">
      <h3>Welcome To Sephora</h3>
      
      <a href="front.php" class="btn">discover more</a>
   </div>

</section>



<?php @include 'footer.php'; ?>

<script src="js/script.js"></script>

</body>
</html>