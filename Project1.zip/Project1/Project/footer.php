<section class="footer"style="background-color:black;">

    <div class="box-container" style="text-decoration: none">

        <div class="box"style="text-decoration: none">
            <h3>Quick links</h3>
            <a style="text-decoration: none;"href="front.php">Home</a>
            <a style="text-decoration: none"href="about.php">About</a>
            <a style="text-decoration: none"href="contact.php">Contact</a>
            <a style="text-decoration: none"href="front.php">Shop</a>
        </div>

        <div class="box">
            <h3>Extra links</h3>
           
            <a style="text-decoration: none"href="orders.php">My orders</a>
            <a style="text-decoration: none"href="cart.php">My cart</a>
        </div>

        <div class="box">
            <h3>contact info</h3>
            <p> <i class="fas fa-phone"></i> +8801903152971</p>
            <p> <i class="fas fa-phone"></i> +8801989355162 </p>
            <p> <i class="fas fa-envelope"></i> sanjidarehman36@gmail.com </p>
            <p> <i class="fas fa-map-marker-alt"></i> Dhaka,Bangladesh</p>
        </div>

        <div class="box">
            <h3>follow us</h3>
            <a style="text-decoration: none"href="https://www.facebook.com/sephoraindia/?brand_redir=16453004404"><i class="fab fa-facebook-f"></i>facebook</a>
            <a style="text-decoration: none" href="https://twitter.com/Sephora?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor"><i class="fab fa-twitter"></i>twitter</a>
            <a style="text-decoration: none"href="https://www.instagram.com/sephora/?hl=en"><i class="fab fa-instagram"></i>instagram</a>
           
        </div>

    </div>

    <div class="credit">&copy; copyright @ <?php echo date('Y'); ?> by <span>Sephora</span> </div>

</section>